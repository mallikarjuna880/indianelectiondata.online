let catalogue = null;
let currentElection = null;

const $ = (id) => document.getElementById(id);
const fmt = (n) => new Intl.NumberFormat("en-IN").format(n);

async function loadCatalogue() {
  const res = await fetch("data/elections.json");
  if (!res.ok) throw new Error("Could not load election catalogue.");
  catalogue = await res.json();

  $("electionSelect").innerHTML = catalogue.elections.map(e =>
    `<option value="${e.id}">${e.label}</option>`).join("");

  $("electionSelect").addEventListener("change", loadElection);
  $("search").addEventListener("input", renderAll);
  $("stateSelect").addEventListener("change", renderAll);
  $("partySelect").addEventListener("change", renderAll);

  await loadElection();
}

async function loadElection() {
  const meta = catalogue.elections.find(e => e.id === $("electionSelect").value);
  if (!meta) return;

  const res = await fetch(meta.dataset);
  if (!res.ok) throw new Error(`Could not load ${meta.dataset}`);
  currentElection = await res.json();

  populateFilters();
  renderAll();
}

function populateFilters() {
  const states = [...new Set(currentElection.results.map(r => r.state))].sort();
  const parties = [...new Set(currentElection.results.map(r => r.party))].sort();

  $("stateSelect").innerHTML = `<option value="">All states</option>` +
    states.map(s => `<option>${s}</option>`).join("");
  $("partySelect").innerHTML = `<option value="">All parties</option>` +
    parties.map(p => `<option>${p}</option>`).join("");
}

function filteredResults() {
  const q = $("search").value.trim().toLowerCase();
  const state = $("stateSelect").value;
  const party = $("partySelect").value;

  return currentElection.results.filter(r => {
    const text = [r.constituency, r.state, r.winner, r.party].join(" ").toLowerCase();
    return (!q || text.includes(q)) && (!state || r.state === state) && (!party || r.party === party);
  });
}

function renderResults() {
  const rows = filteredResults();
  $("resultsBody").innerHTML = rows.length ? rows.map(r => `
    <tr>
      <td><strong>${r.constituency}</strong></td>
      <td>${r.state}</td>
      <td>${r.winner}</td>
      <td><span class="party-pill">${r.party}</span></td>
      <td>${fmt(r.votes)}</td>
      <td>${fmt(r.margin)}</td>
    </tr>`).join("") :
    '<tr><td colspan="6" class="empty">No matching records found.</td></tr>';
}

function renderSummary() {
  $("heroElection").textContent = `${currentElection.type} ${currentElection.year}`;
  $("heroRecords").textContent = fmt(currentElection.results.length);
  $("heroParties").textContent = fmt(currentElection.parties.length);
  $("heroStates").textContent = fmt(currentElection.states.length);
  $("statElection").textContent = `${currentElection.type} ${currentElection.year}`;
  $("statType").textContent = currentElection.type;
  $("statStatus").textContent = currentElection.status === "verified" ? "● Verified" : "● Demo";
  $("sourceNote").textContent = currentElection.source?.note || "";
}

function renderParties() {
  const parties = currentElection.parties;
  const max = Math.max(...parties.map(p => p.seats), 1);
  $("partyCards").innerHTML = parties.map(p => `
    <article class="party-card">
      <div class="top"><h3>${p.name}</h3><span class="party-pill">Seats</span></div>
      <div class="seats">${fmt(p.seats)}</div>
      <div class="bar"><span style="width:${(p.seats / max) * 100}%"></span></div>
    </article>`).join("");
}

function renderStates() {
  $("stateCards").innerHTML = currentElection.states.map(s => `
    <article class="state-card">
      <div class="top"><h3>${s.name}</h3><span class="party-pill">${fmt(s.seats)} seats</span></div>
      <p>Constituency-level data will be expanded in later phases.</p>
      <p><strong>Current view:</strong> ${s.leading}</p>
    </article>`).join("");
}

function renderAll() {
  if (!currentElection) return;
  renderSummary();
  renderResults();
  renderParties();
  renderStates();
}

loadCatalogue().catch(err => {
  console.error(err);
  document.body.insertAdjacentHTML("afterbegin",
    `<div class="error-banner">Election data could not be loaded. Please refresh the page.</div>`);
});
