# Indian Election Data — dataset structure

- `elections.json` — catalogue of available elections.
- `loksabha/YYYY.json` — Lok Sabha election datasets.
- `assembly/<state-slug>/YYYY.json` — future State Assembly datasets.

All factual datasets should include a source and methodology note.
