# Indian Election Data

Phase 1: scalable static-site data architecture for `indianelectiondata.online`.

## Structure
- `data/elections.json` — election catalogue
- `data/loksabha/YYYY.json` — Lok Sabha datasets
- `data/assembly/<state>/YYYY.json` — future Assembly datasets
- `app.js` — loads the catalogue and selected dataset dynamically

The included 2024 dataset is still the existing prototype/demo data and must be replaced with verified authoritative data before publication.
